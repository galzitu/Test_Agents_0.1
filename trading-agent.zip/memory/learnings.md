# Learnings - מה הסוכן למד

*עדכון אחרון: 2026-03-21 07:06*


## Market_Timing

- No trades on 2026-03-20 (Friday). Agent ran full session but executed 0 trades. Likely causes: (1) Carry-over cooling from 6 consecutive losses on 2026-03-19, (2) RANGING market (ADX<20) blocked trend-following strategies, (3) Mean-reversion strategies (VWAP, Bollinger) didn't generate signals above threshold. Pattern: RANGING Friday after a losing day = no-trade day. Action: No changes needed. Monitor Monday opening for fresh start. (0 trades, 2026-03-20)

## Strategy_Activation

- EMA_Crossover_9_21 fired 6 times in RANGING market (ADX=15) and hit stop-loss on all 6 trades (100% loss rate, avg -$3.46/trade). EMA crossover is a trend-following strategy and must not activate in ranging conditions. Fixed: removed RANGING from activation, raised adx_min 15→25. (6 trades, 2026-03-19)

## Risk_Management

- 5 nearly identical trades on SPY fired within 3 minutes (16:15-16:18) with the same entry_price and indicators. All hit stop-loss for $-16/total. Strategy generates repeated signals when conditions persist tick-by-tick. Need a per-symbol cooldown (min 5 min) between entries by same strategy. (5 trades, 2026-03-19)

## Signal_Quality

- All 6 losing EMA trades had EMA(9)-EMA(21) spread of only $0.03 on SPY at ~$658 (0.005%). A crossover this small is statistical noise, not a real trend signal. Consider adding min_ema_spread_pct threshold (e.g. 0.05%) to EMA crossover logic. (6 trades, 2026-03-19)
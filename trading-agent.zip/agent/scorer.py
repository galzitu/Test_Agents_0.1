"""
Strategy Scorer - Calculates scores based on real trading performance.
Score = weighted combination of win rate, profit factor, risk/reward.
Only reliable after 30+ trades.
"""

import json
import logging
from pathlib import Path

from agent.config import ScoringConfig, STRATEGIES_CONFIG_DIR
from agent.memory import Memory

logger = logging.getLogger(__name__)


class StrategyScorer:
    """
    Scores strategies 0-100 based on actual trading results.

    Formula:
      win_rate_score = (wins/total) * 40       (40% weight)
      profit_factor_score = min(PF/3, 1) * 35  (35% weight)
      risk_reward_score = min(RR/3, 1) * 25    (25% weight)
      final = sum of above (0-100)

    Rules:
    - Under 30 trades: score = 50 (neutral, trial period)
    - Under 50 trades: can't disable
    - Recalculated after every closed trade
    """

    def __init__(self, memory: Memory):
        self.memory = memory
        self.config = ScoringConfig

    def get_all_strategy_names(self) -> list[str]:
        """Load all strategy display names from strategy config files."""
        names = []
        for path in sorted(STRATEGIES_CONFIG_DIR.glob("*.json")):
            if path.name in {"scores.json", "allocation.json"}:
                continue
            try:
                with open(path) as f:
                    config = json.load(f)
                if config.get("name"):
                    names.append(config["name"])
            except Exception as e:
                logger.warning(f"Failed to load strategy name from {path}: {e}")
        return names

    def calculate_score(self, strategy_name: str) -> dict:
        """
        Calculate score for a strategy based on all its closed trades.

        Returns dict with score + all metrics.
        """
        perf = self.memory.get_strategy_performance(strategy_name)

        total = perf["total_trades"]
        if total == 0:
            return {
                "strategy": strategy_name,
                "score": self.config.DEFAULT_SCORE,
                "total_trades": 0,
                "status": "new",
                "message": "No trades yet",
            }

        if total < self.config.MIN_TRADES_FOR_SCORE:
            return {
                "strategy": strategy_name,
                "score": self.config.DEFAULT_SCORE,
                "total_trades": total,
                "status": "trial",
                "message": f"Trial period ({total}/{self.config.MIN_TRADES_FOR_SCORE} trades)",
                "win_rate": perf["win_rate"],
                "profit_factor": perf["profit_factor"],
                "avg_risk_reward": perf["avg_risk_reward"],
            }

        # Calculate weighted score
        win_rate = perf["win_rate"]
        profit_factor = perf["profit_factor"]
        avg_rr = perf["avg_risk_reward"]

        win_rate_score = win_rate * self.config.WIN_RATE_WEIGHT
        pf_score = min(profit_factor / 3, 1.0) * self.config.PROFIT_FACTOR_WEIGHT
        rr_score = min(avg_rr / 3, 1.0) * self.config.RISK_REWARD_WEIGHT

        final_score = round(win_rate_score + pf_score + rr_score)
        final_score = max(0, min(100, final_score))  # Clamp 0-100

        # Determine status
        if final_score >= 70:
            status = "strong"
        elif final_score >= 50:
            status = "decent"
        elif final_score >= 30:
            status = "weak"
        else:
            status = "failing"

        return {
            "strategy": strategy_name,
            "score": final_score,
            "total_trades": total,
            "status": status,
            "win_rate": win_rate,
            "profit_factor": profit_factor,
            "avg_risk_reward": avg_rr,
            "breakdown": {
                "win_rate_score": round(win_rate_score, 1),
                "profit_factor_score": round(pf_score, 1),
                "risk_reward_score": round(rr_score, 1),
            },
        }

    def update_scores(self, strategy_names: list[str]) -> dict[str, dict]:
        """
        Recalculate scores for multiple strategies.
        Saves to scores.json and database.
        """
        results = {}

        for name in strategy_names:
            result = self.calculate_score(name)
            results[name] = result

            # Save to database
            self.memory.save_score(
                strategy=name,
                score=result["score"],
                total_trades=result["total_trades"],
                win_rate=result.get("win_rate", 0),
                profit_factor=result.get("profit_factor", 0),
                avg_risk_reward=result.get("avg_risk_reward", 0),
                allocation_pct=0,  # Will be set by allocator
                reason=result.get("status", ""),
            )

        # Save to scores.json
        self._save_scores_json(results)
        return results

    def _save_scores_json(self, results: dict):
        """Save current scores to strategies_config/scores.json."""
        from datetime import datetime

        scores_path = STRATEGIES_CONFIG_DIR / "scores.json"
        data = {
            "last_updated": datetime.now().isoformat(),
            "scores": {name: r["score"] for name, r in results.items()},
            "details": {
                name: {
                    "score": r["score"],
                    "status": r.get("status", "?"),
                    "total_trades": r["total_trades"],
                    "win_rate": r.get("win_rate", 0),
                }
                for name, r in results.items()
            },
        }

        with open(scores_path, "w") as f:
            json.dump(data, f, indent=2)

        logger.info(f"Scores saved to {scores_path}")

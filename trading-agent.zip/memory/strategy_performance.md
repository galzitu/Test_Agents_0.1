# Strategy Performance - ביצועי אסטרטגיות

*עדכון אחרון: 2026-03-21 07:06*

| Strategy | Score | Trades | Win Rate | PF | Alloc |
|----------|-------|--------|----------|-----|-------|
| Bollinger_Squeeze | 50 | 0 | 0% | 0.0 | 0% |
| Opening_Range_Breakout | 50 | 0 | 0% | 0.0 | 0% |
| RSI_MACD_Momentum | 50 | 0 | 0% | 0.0 | 0% |
| VWAP_Mean_Reversion | 50 | 0 | 0% | 0.0 | 0% |
| Volume_Spike_Momentum | 50 | 0 | 0% | 0.0 | 0% |
| EMA_Crossover_9_21 | 2 | 6 | 0% | 0.0 | 0% |